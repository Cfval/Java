/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import lloguervaixells.Esportiu;
import lloguervaixells.Iot;
import lloguervaixells.Lloguer;
import lloguervaixells.Veler;

/**
 *
 * @author jmas
 */
public class TestLloguer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Iot iot = new Iot(5, 20, "784V", 10.25, 2022);
        Esportiu esportiu = new Esportiu(3, "981T", 10.5, 2020);
        Veler veler = new Veler(2, "652X", 2.15, 2010);
        
        Lloguer l1 = new Lloguer("Pepito", "45874512T", 4, 25, iot);
        Lloguer l2 = new Lloguer("Luisa", "87965487S", 2, 12, veler);
        Lloguer l3 = new Lloguer("Laura", "78495671Q", 4, 12, esportiu);
        
        System.out.println(l1.getPreuLloguer());
        System.out.println(l2.getPreuLloguer());
        System.out.println(l3.getPreuLloguer());
    }
    
}
