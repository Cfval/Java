/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lloguervaixells.Esportiu;
import lloguervaixells.Iot;
import lloguervaixells.Vaixell;
import lloguervaixells.Veler;
import java.time.LocalDate;

/**
 *
 * @author Cfval
 */
public class AddVaixell extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        
        
            ArrayList<Vaixell> llistaVaixells = (ArrayList<Vaixell>) request.getSession().getAttribute("llistaVaixells");
        
            if(llistaVaixells == null) llistaVaixells = new ArrayList<>(); 
           
            String matricula = request.getParameter("matricula");
            String tipoVaixell = request.getParameter("tipus");
            int anyFabricacio = -1;
            double eslora = -1;
            int potencia = -1;
        
            try {
                eslora = Double.parseDouble(request.getParameter("eslora"));
                if(eslora < 0) throw new NumberFormatException("La longitud no puede ser negativa");
            } catch (NumberFormatException e) {
                request.getSession().setAttribute("error", e.getMessage());
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }
        
            try {
                anyFabricacio = Integer.parseInt(request.getParameter("anyFabricacio"));
                int anyActual = LocalDate.now().getYear();
                if(anyFabricacio < 1500 || anyFabricacio > anyActual) throw new NumberFormatException("Any de fabricació invalid");
            } catch (NumberFormatException e) {
                request.getSession().setAttribute("error", e.getMessage());
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }
        
           
            if (Vaixell.buscar(llistaVaixells, matricula) != null) {
                request.getSession().setAttribute("error", "Ya existix un vaixell amb la matrícula proporcionada.");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
                return;
            }

            
            Vaixell vaixell = null;
            switch (tipoVaixell) {
                case "esportiu":
      
                    try {
                        potencia = Integer.parseInt(request.getParameter("potencia"));
                    if(potencia < 0) throw new NumberFormatException("No pot ser una potència negativa");
                    } catch (NumberFormatException e) {
                        request.getSession().setAttribute("error", e.getMessage());
                        request.getRequestDispatcher("/error.jsp").forward(request, response);
                        return;
                    }
                
                    vaixell = new Esportiu(matricula, eslora, anyFabricacio, potencia);
                    break;
                case "veler":
                    int numVelas = 0; 
                
                    try {
                        numVelas = Integer.parseInt(request.getParameter("mastelers"));
                    if(numVelas < 0) throw new NumberFormatException("No pot haver un número negatiu de mastelers");
                    } catch (NumberFormatException e) {
                        request.getSession().setAttribute("error", e.getMessage());
                        request.getRequestDispatcher("/error.jsp").forward(request, response);
                        return;
                    }
                
                    vaixell = new Veler(numVelas, matricula, eslora, anyFabricacio);
                    break;
                case "iot":
                    int numCamarotes = 0; 
                
                    try {
                        numCamarotes = Integer.parseInt(request.getParameter("cabines"));
                        potencia = Integer.parseInt(request.getParameter("potencia"));
                    
                    if(numCamarotes < 0) throw new NumberFormatException("La quantitat de cavines no pot ser negatiu");
                    if(potencia < 0) throw new NumberFormatException("No pot ser una potència negativa");
                    } catch (NumberFormatException e) {
                        request.getSession().setAttribute("error", e.getMessage());
                        request.getRequestDispatcher("/error.jsp").forward(request, response);
                        return;
                    }
                
                    vaixell = new Iot(matricula, eslora, anyFabricacio, numCamarotes, potencia);
                    break;
                default:
                    request.getSession().setAttribute("error", "Tipus de vaixell no suportat.");
                    request.getRequestDispatcher("/error.jsp").forward(request, response);
                    return;
            }
        
            llistaVaixells.add(vaixell);
            
            String missatge = "Vaixell inserit amb exit";
            request.getSession().setAttribute("missatge", missatge);
            request.getSession().setAttribute("llistaVaixells", llistaVaixells);
            response.sendRedirect("llistaVaixells.jsp");
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
