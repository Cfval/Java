/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lloguervaixells.Lloguer;
import lloguervaixells.Vaixell;
import java.util.regex.Pattern;

/**
 *
 * @author Cfval
 */
public class calcularLloguer extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        
        //String matricula = (String) request.getSession().getAttribute("matricula");
        ArrayList<Vaixell> llistaVaixells = (ArrayList<Vaixell>) request.getSession().getAttribute("llistaVaixells");
        
        String matricula = request.getParameter("matricula");
        String nom = request.getParameter("nom");
        String dni = request.getParameter("dni").toUpperCase(); 
        int diesOcupacio = -1;
        diesOcupacio = Integer.parseInt(request.getParameter("diesOcupacio"));
        int amarratge = -1;
        amarratge = Integer.parseInt(request.getParameter("amarratge"));
        
        if(llistaVaixells == null) llistaVaixells = new ArrayList<>();
        
        // Comprovem si la matrícula existix, si existix una llista de vaixells y si la matrícula coincidix amb la de un vaixell en la llista
        if (matricula == null || llistaVaixells == null || Vaixell.buscar(llistaVaixells, matricula) == null) {
            request.getSession().setAttribute("error", "Algo ha fallat");
            request.getRequestDispatcher("llistaVaixells.jsp").forward(request, response);
            return;
        }
            
        try {
                
            if (nom == null || nom.length() < 2 || nom.length() > 250) {
                throw new Exception("El nom no es valid o excedix els 250 caracters");
            }
                
            String dniPatro = "\\d{8}[A-Z]";
            if (dni == null || !Pattern.matches(dniPatro, dni)) {
                throw new Exception("El DNI no es válid");
            }
                
            if(diesOcupacio < 0 || amarratge < 0) throw new Exception ("No pots introduir un número negatiu o deixar en blanc");
                                
                Lloguer lloguer = new Lloguer(nom, dni, diesOcupacio, amarratge, Vaixell.buscar(llistaVaixells, matricula));
                
                request.getSession().setAttribute("lloguer", lloguer);
                String missatge = "Simulació completada";
                request.getSession().setAttribute("missatge", missatge);
            }
            catch(Exception ex){
                
                String missatge = "Simulació fallida: ";
                request.getSession().setAttribute("error", missatge + ex.getMessage());
                request.getRequestDispatcher("/llistaVaixells.jsp").forward(request, response);
                // La pàgina saltarà directament a la vista llistaVaixells.jsp sense mostrar el missatge de error
          
            }
            
        response.sendRedirect("mostrarLloguer.jsp");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
