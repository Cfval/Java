/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercici3;


import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 *
 * @author ciclost
 */
public class Exercici3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Function<Predicate<String>, Function<List<String>,List<String>>> filtrador = predicat -> llista -> 
                llista.stream().filter(predicat).collect(Collectors.toList());  //Llista que recolecta els elements que no compleixen el predicat del .filter
        
    }
    
}
