package principal;

import dao.*;
import dto.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Principal {

    public static void main(String[] args) {
        
        // A) Mostra aquells professors que imparteixen més de dos assignatures (mostra l'objecte professor complet) [0.2p]
        ProfessorDAO.getAll().stream()
            .filter(p -> p.getAssignatures().size() > 2)
            .forEach(System.out::println);
        
        
        // B) Mostra el nom de les assignatures impartides per tots els professors, sense duplicats i ordenades alfabèticament. [0.2p]
        List<String> assignatures = ProfessorDAO.getAll().stream()
            .flatMap(p -> p.getAssignatures().stream())
            .map(Assignatura::getNom)
            .distinct()
            .sorted()
            .collect(Collectors.toList());

        assignatures.forEach(System.out::println);

        // C) Recol·lecta i mostra un mapa (Map) on s'associe per a cada nom de professor la quantitat d'assignatures que imparteix [0.4p]
        Map<String, Integer> quantitatAssignatures = ProfessorDAO.getAll().stream()
            .collect(Collectors.toMap(
                                        Professor::getNom,
                                        p -> p.getAssignatures().size()
            ));

        quantitatAssignatures.forEach((nom, compte) -> System.out.println(nom + ": " + compte));


        // D) Recol·lecta i mostra un mapa (Map) on s'associe per a cada nom de professor la quantitat d'hores de classe que imparteix [0.4p]
        Map<String, Integer> horesPerProfessor = ProfessorDAO.getAll().stream()
            .collect(Collectors.toMap(
                                        Professor::getNom,
                                        p -> p.getAssignatures().stream().mapToInt(Assignatura::getHoresSetmanals).sum()
            ));

        horesPerProfessor.forEach((nom, hores) -> System.out.println(nom + ": " + hores));

      
        // E) Recol·lecta i mostra un mapa (Map) on s'associe per a cada DNI de professor el curs més alt on imparteix classe (si no te cap assignatura associada, el màxim curs serà 0) [0.5p]
        

        // F) Recol·lecta i mostra un mapa (Map) on s'associe per a cada curs els noms d'assignatures d'eixe curs (separades per un guionet " - "). [0.6p]
        Map<Integer, String> nomsPerCurs = AssignaturaDAO.getAll().stream()
                    .collect(Collectors.groupingBy(
                                                    Assignatura::getCurs,
                                           Collectors.mapping(Assignatura::getNom, Collectors.joining(" - "))
                    ));

        nomsPerCurs.forEach((curs, noms) -> System.out.println(curs + ": " + noms));

        // G) Recol·lecta i mostra un mapa (Map) on s'associe per a cada assignatura la llista de professors que la imparteixen [0.7p]
    }

}
