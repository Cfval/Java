package dto;

import java.util.Objects;
public class Assignatura {
    private final String nom;
    private final int curs;
    private final int horesSetmanals;

    public Assignatura(String nom, int curs, int horesSetmanals) {
        this.nom = nom;
        this.curs = curs;
        this.horesSetmanals = horesSetmanals;
    }

    public String getNom() {
        return nom;
    }

    public int getCurs() {
        return curs;
    }

    public int getHoresSetmanals() {
        return horesSetmanals;
    }

    @Override
    public String toString() {
        return "Assignatura{" + "nom=" + nom + ", curs=" + curs + ", horesSetmanals=" + horesSetmanals + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.nom);
        hash = 89 * hash + this.curs;
        hash = 89 * hash + this.horesSetmanals;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Assignatura other = (Assignatura) obj;
        if (this.curs != other.curs) {
            return false;
        }
        if (this.horesSetmanals != other.horesSetmanals) {
            return false;
        }
        return Objects.equals(this.nom, other.nom);
    }
    
    
}
