package dto;

import java.util.List;
import java.util.Objects;

public class Professor {

    private final String dni;
    private final String nom;
    private final List<Assignatura> assignatures;

    public Professor(String dni, String nom, List<Assignatura> assignatures) {
        this.dni = dni;
        this.nom = nom;
        this.assignatures = assignatures;
    }

    public String getDni() {
        return dni;
    }

    public String getNom() {
        return nom;
    }

    public List<Assignatura> getAssignatures() {
        return assignatures;
    }

    @Override
    public String toString() {
        return "Professor{" + "dni=" + dni + ", nom=" + nom + ", assignatures=" + assignatures + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.dni);
        hash = 67 * hash + Objects.hashCode(this.nom);
        hash = 67 * hash + Objects.hashCode(this.assignatures);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Professor other = (Professor) obj;
        if (!Objects.equals(this.dni, other.dni)) {
            return false;
        }
        if (!Objects.equals(this.nom, other.nom)) {
            return false;
        }
        return Objects.equals(this.assignatures, other.assignatures);
    }
    
    
    
    
}
