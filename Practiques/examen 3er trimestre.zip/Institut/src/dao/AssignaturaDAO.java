package dao;

import dto.Assignatura;
import java.util.ArrayList;
import java.util.List;

public class AssignaturaDAO {

    public static List<Assignatura> getAll() {
        List<Assignatura> assignatures = new ArrayList<>();
        assignatures.add(new Assignatura("Càlcul", 1, 5));
        assignatures.add(new Assignatura("Física", 1, 4));
        assignatures.add(new Assignatura("Programació bàsica", 1, 6));
        assignatures.add(new Assignatura("Sistemes operatius", 2, 5));
        assignatures.add(new Assignatura("Algorísmia i complexitat", 2, 6));
        assignatures.add(new Assignatura("Arquitectura de computadors", 2, 5));
        assignatures.add(new Assignatura("Bases de dades", 3, 5));
        assignatures.add(new Assignatura("Xarxes de computadors", 3, 5));
        assignatures.add(new Assignatura("Programació orientada a objectes", 3, 6));
        assignatures.add(new Assignatura("Introducció a la intel·ligència artificial", 4, 5));
        return assignatures;
    }
}
