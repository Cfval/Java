package dao;

import dto.Assignatura;
import dto.Professor;
import java.util.ArrayList;
import java.util.List;

public class ProfessorDAO {

    public static List<Professor> getAll() {
        List<Assignatura> assignatures = AssignaturaDAO.getAll();
        List<Professor> professors = new ArrayList<>();
        professors.add(new Professor("12345678A", "Grace Hopper", List.of(assignatures.get(0))));
        professors.add(new Professor("23456789B", "Alan Turing", List.of(assignatures.get(7))));
        professors.add(new Professor("34567890C", "Ada Lovelace", List.of(assignatures.get(2))));
        professors.add(new Professor("45678901D", "Linus Torvalds", List.of(assignatures.get(2), assignatures.get(5))));
        professors.add(new Professor("67890123F", "Ada Yonath", List.of(assignatures.get(3), assignatures.get(6), assignatures.get(9))));
        professors.add(new Professor("78901234G", "Donald Knuth", List.of(assignatures.get(3), assignatures.get(8), assignatures.get(4))));

        return professors;
    }
}
