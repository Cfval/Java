/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import moduls.Cotxe;

/**
 *
 * @author ciclost
 */
public class AddCotxes extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");

        ArrayList<Cotxe> llistaCotxes = (ArrayList<Cotxe>) request.getSession().getAttribute("llistaCotxes");
        if (llistaCotxes == null) llistaCotxes = new ArrayList<>();

        try {
            String matricula = request.getParameter("matricula");
            String model = request.getParameter("model");
            String color = request.getParameter("color");
            boolean aire = "si".equals(request.getParameter("aire"));
            double preu = Double.parseDouble(request.getParameter("preudia"));
            int dies = Integer.parseInt(request.getParameter("dies"));

            if (preu < 0 || dies < 0) {
                throw new NumberFormatException("No pots introduir un valor negatiu.");
            }

            Cotxe nouCotxe = new Cotxe(matricula, model, aire, color, preu, dies);
            llistaCotxes.add(nouCotxe);

            request.getSession().setAttribute("llistaCotxes", llistaCotxes);
            response.sendRedirect("lloguers.jsp");

        } catch (NumberFormatException e) {
            request.getSession().setAttribute("error", e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
