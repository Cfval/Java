/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package moduls;

import java.util.Objects;

public class Cotxe {
    private final boolean aire;
    private final String color;
    private final int dies;
    private final String matricula;
    private final String modelo;
    private final double preu;

    public Cotxe(String matricula, String modelo, boolean aire, String color, double preu, int dies) {
        this.matricula = matricula;
        this.modelo = modelo;
        this.aire = aire;
        this.color = color;
        this.preu = preu;
        this.dies = dies;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cotxe other = (Cotxe) obj;
        return Objects.equals(this.matricula, other.matricula);
    }
    public String getColor() {
        return color;
    }
    public int getDies() {
        return dies;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getModelo() {
        return modelo;
    }


    public double getPreu() {
        return preu;
    }

    
    public String getPreuMoneda(){
        return String.format("%.2f€", getPreu());
    }
    
    public String getPreuTotalMoneda(){
        return String.format("%.2f€", getPreu() * getDies());
    }


    @Override
    public int hashCode() {
        int hash = 5;
        hash = 67 * hash + Objects.hashCode(this.matricula);
        return hash;
    }
    public boolean isAire() {
        return aire;
    }
    @Override
    public String toString() {
        return "Cotxe{" + "matricula=" + matricula + ", modelo=" + modelo + ", aire=" + aire + ", color=" + color + ", preu=" + preu + ", dies=" + dies + '}';
    }
    
    
    
}
