/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Cfval
 */
public class Figura {

    final String color;
    
    public Figura(String color){
        this.color = color;
    }
    
    public String getColor() {
        return color;
    }
    
    /* 
    Realment deuria haber treballat amb una clase abstracta: public abstract class Figura {
    Només caldria introduir els metodes abstractes: public abstract double getPerimetre():
    public abstract double getArea(): 
    */
}
