/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Cfval
 */
public class TriangleEquilater extends Figura{
    private final double base;
    private final double altura;

    public TriangleEquilater(double base, double altura, String color) {
        super (color);
        this.base = base;
        this.altura = altura;
    }
    
    public double getBase(){
        return base;
    }
    
    public double getAltura(){
        return altura;
    }
    /* 
    // Están mal creats els dos seguients metodes ja que no gastem els parametres que entren 
    public double getArea(double base, double altura){
        return 0.5 * base * altura;
    }
    
    public double getPerimetre(double altura){
        // Calculem la longitud d'un costat
        double lado = (2 * altura) / Math.sqrt(3);
        return 3 * lado;
    }*/

    @Override
    public String getColor() {
        return color;
    }
    
    @Override
    public String toString(){
        return "Triangle equilàter [base= " + base + ", altura=" + altura + "]";
    }

    public double getPerimetre() {
        double lado = (2 * altura) / Math.sqrt(3);
        return 3 * lado;
    }
    
    public double getArea() {
        return 0.5 * base * altura;
    }
}
