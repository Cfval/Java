/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Cfval
 */
public class Rectangle extends Figura{
    private final double base;
    private final double altura;
    
    public Rectangle(double base, double altrua, String color){
        super (color);
        this.base = base;
        this.altura = altrua; 
    }

    public double getBase() {
        return base;
    }

    public double getAltura() {
        return altura;
    }
    
   // Están mal creats els dos seguients metodes ja que no gastem els parametres que entren 
    public static double getArea(double base, double altura){
        return base * altura;
    }
    
    public double getPerimetre(double base, double altura){
        return 2*base + 2*altura;
    }
    
    @Override
    public String getColor() {
        return color;
    }
    
    @Override
    public String toString() {
        return "Rectangle [base=" + base + ", altura=" + altura + "]";
    }


    public double getPerimetre(){
        return 2*base + 2*altura;
    }


    public double getArea() {
        return base * altura;
    }
    
}
