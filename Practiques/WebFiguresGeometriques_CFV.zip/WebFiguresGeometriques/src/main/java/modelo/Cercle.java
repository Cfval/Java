/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Cfval
 */
public class Cercle extends Figura{
    private final double radi;
    
    public Cercle(double radi, String color){
        super (color);
        this.radi = radi;
    }
    
    public double getRadi(){
        return radi;
    }
    /*
    // Están mal creats els dos seguients metodes ja que no gastem els parametres que entren 
    public double getArea(double radi){
        return Math.PI * Math.pow(radi, 2);
    }
    
    public double getPerimetre(double radi){
        return 2 * Math.PI * radi;
    }*/

    @Override
    public String getColor() {
        return color;
    }
    
    @Override
    public String toString(){
        return "Cercle [radi= " + radi + "]";
    }

    public double getPerimetre() {
         return Math.PI * Math.pow(radi, 2);
    }

    public double getArea() {
        return 2 * Math.PI * radi;
    }
}
