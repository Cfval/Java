/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Cercle;
import modelo.Figura;
import modelo.Rectangle;
import modelo.TriangleEquilater;

/**
 *
 * @author Cfval
 */
public class ProcessarFormulari extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        try{
            ArrayList<Figura> figures = (ArrayList<Figura>)request.getSession().getAttribute("figures");
            if(figures==null) figures = new ArrayList<>();
            
            String color = request.getParameter("color");
            String tipusFigura = request.getParameter("figura");
            //inicie les variables a -1 per asegurar el trycatch en el switch, i així m'ahorre inicialitzarles dins de cada cas.
            double base = -1;
            double altura = -1;
            double radi = -1;
            
            //figures.add(new Rectangle(base, altura, color)); -- NO
            //Iniciem un objecte figura a null per a després crear un en el SWITCH depenent de quin tipus de figura siga.
            Figura figura = null;
            
            // Es pot utilitzar la estrictura if, else if.. : if (tipusFigura.equals("rectangle")){   i ja dins recollim variables i el try catch.
            
            //tipusFigura te dins el string que ve per parametre del "select" figura en el index.html
            switch (tipusFigura){
                case "rectangle":
                    base = Double.parseDouble(request.getParameter("baseRectangle"));
                    altura = Double.parseDouble(request.getParameter("alturaRectangle"));
                    try{
                        if(base<0 || altura <0) throw new NumberFormatException ("No pots introduir un valor negatiu.");
                        
                    }catch(NumberFormatException e){
                        request.getSession().setAttribute("error", e.getMessage());
                        request.getRequestDispatcher("error.jsp").forward(request, response);
                        return;
                    }
                    figura = new Rectangle(base, altura, color);
                    break;
                    
                case "triangle":
                    base = Double.parseDouble(request.getParameter("baseTriangle"));
                    altura = Double.parseDouble(request.getParameter("alturaTriangle"));
                    try{
                        if(base<0 || altura <0) throw new NumberFormatException ("No pots introduir un valor negatiu.");
                    }catch(NumberFormatException e){
                        request.getSession().setAttribute("error", e.getMessage());
                        request.getRequestDispatcher("error.jsp").forward(request, response);
                        return;
                    }
                    figura = new TriangleEquilater(base, altura, color);
                    break;
                    
                case "cercle":
                    radi = Double.parseDouble(request.getParameter("radi"));
                    try{
                        if(radi<0) throw new NumberFormatException ("No pots introduir un valor de radi negatiu.");
                    }catch(NumberFormatException e){
                        request.getSession().setAttribute("error", e.getMessage());
                        request.getRequestDispatcher("error.jsp").forward(request, response);
                        return;
                    }
                    figura = new Cercle(radi, color);
                    break;
                    
                default:
                    request.getSession().setAttribute("error", "Tipus de figura no suportada.");
                    request.getRequestDispatcher("error.jsp").forward(request, response);
                    return;
            }
            
            figures.add(figura); //añadim la figura al arraylist de figures de la sessió
            
            //Comentem la jugada y guardem els atreibuts, després redirigim a taula.jsp per sendRedirect
            String missatge = "Figura inserida amb exit";
            request.getSession().setAttribute("missatge", missatge);
            request.getSession().setAttribute("figures", figures);
            response.sendRedirect("taula.jsp");
            
            } catch(IOException | NumberFormatException | ServletException ex){
                request.getSession().setAttribute("error", "Ha habut un error, disculpa les molesties.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
            }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
