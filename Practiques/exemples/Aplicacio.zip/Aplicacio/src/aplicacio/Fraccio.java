/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplicacio;

import java.math.BigInteger;

public class Fraccio {
    
    //ATRIBUTS
    private int numerador;
    private int denominador;
    
    //MÈTODES CONSTRUCTORS
    public Fraccio(int numerador, int denominador){
        this.numerador = numerador;
        this.denominador = denominador;
    }
    
    public Fraccio(int numerador){
        this(numerador, 1);
    }
    
    public Fraccio(){
        this(0);
    }
    
    public Fraccio(double decimal){
        this.denominador = 1;
        while(decimal % 1 != 0){
            decimal *= 10;
            this.denominador *= 10;
        }
        this.numerador = (int) decimal;
    }
    
    public Fraccio(Fraccio f){
        this(f.numerador,f.denominador);
    }
    
    
    //MÈTODES DE CLASSE
    public static Fraccio sumar(Fraccio f1, Fraccio f2){
        return f1.mes(f2);
    }
    
    public static Fraccio restar(Fraccio f1, Fraccio f2){
        return f1.menys(f2);
    }
    
    //MÈTODES D'INSTÀNCIA
    public Fraccio mes(Fraccio f){
        int num = this.numerador * f.denominador + this.denominador * f.numerador;
        int den = this.denominador * f.denominador;
        return new Fraccio(num,den);
    }
    
    public Fraccio mes(int entero){
        return this.mes(new Fraccio(entero));
    }
    
    public Fraccio mes(double decimal){
        return this.mes(new Fraccio(decimal));
    }
    
    public Fraccio menys(Fraccio f){
        int num = this.numerador * f.denominador - this.denominador * f.numerador;
        int den = this.denominador * f.denominador;
        return new Fraccio(num,den);
    }
    
    public Fraccio menys(int entero){
        return this.menys(new Fraccio(entero));
    }
    
    public Fraccio per(Fraccio f){
        int num = this.numerador * f.numerador;
        int den = this.denominador * f.denominador;
        return new Fraccio(num,den);
    }
    
    public Fraccio entre(Fraccio f){
        int num = this.numerador * f.denominador;
        int den = this.denominador * f.numerador;
        return new Fraccio(num,den);
    }
    
    public Fraccio invertir(){
        return new Fraccio(this.denominador,this.numerador);
    }
    
    public Fraccio simplificar(){
        BigInteger num = new BigInteger(String.valueOf(this.numerador));
        BigInteger den = new BigInteger(String.valueOf(this.denominador));
        BigInteger mcd = num.gcd(den);
        
        return new Fraccio(this.numerador / mcd.intValue(), this.denominador / mcd.intValue());
    }
    
    public Fraccio clonar(){
        return new Fraccio(this);
    }
    
    public double toDouble(){
        return (double) this.numerador / this.denominador;
    }
    
    public void imprimirMixt(){
        int partEntera = (int) (this.numerador / this.denominador);
        Fraccio fraccio = this.menys(partEntera);
        System.out.println(partEntera +" + "+fraccio.simplificar());
    }
    
    @Override
    public String toString(){
        return this.numerador + "/" + this.denominador;
    }
    
}
