/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplicacio;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

/**
 *
 * @author jmas
 */
public class Aplicacio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Persona p1 = new Persona("75849521X", "Pepito López", 32);
        Persona p2 = new Persona("94874621T", "Laura Coves", 31);
        Persona p3 = new Persona("44746921V", "Ana Cazorla", 24);
      
        System.out.println(Stream.of(p1,p2,p3)
                .mapToInt(Persona::getEdat)
                .summaryStatistics());
                
        
        Stream.of(15,4,8,1,-5)
                .mapToInt(n -> n*2)
                .max()
                .ifPresent(System.out::println);
        
              
        int vas;
        

    }

}
