package aplicacio;

public class Persona {
    public String dni;
    private String nom;
    int edat;
    
    public Persona(String nom, String telefon, int importMaxim){
        this.dni = nom;
        this.nom = telefon;
        this.edat = importMaxim;
    }
    
    public Persona(String nom, String telefon){
        this(nom,telefon,10000);
    }
    
    public Persona(Persona g){
        this(g.dni, g.nom, g.edat);
    }
    
    public String getTelefon(){
        return this.nom;
    }

    public String getDni() {
        return dni;
    }

    public String getNom() {
        return nom;
    }

    public int getEdat() {
        return edat;
    }
    
    
    void mostrarInformacio(){
        System.out.println("Nom: " + this.dni);
        System.out.println("Telèfon: " + this.nom);
        System.out.println("Import màxim: " + this.edat);
    }

    @Override
    public String toString() {
        return "Persona{" + "dni=" + dni + ", nom=" + nom + ", edat=" + edat + '}';
    }
    
    
}
